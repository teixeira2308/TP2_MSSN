package physics;

public class Air extends Fluid{
    public Air(float scaling) {
        super(1.29f*scaling);
    }
}