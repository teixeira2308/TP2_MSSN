package physics;

import setup.IProcessing;

public class FallingBodyApp implements IProcessing{  {
    public static final float dimY = 15;
    public static final float dimX = 10;
    
}
